# Related Tutorials

* [Basic Auth with Spring Security](https://howtodoinjava.com/spring-security/http-basic-authentication-example/)
* [Password Encoders in Spring Security](https://howtodoinjava.com/spring-security/password-encoders/)
* [Guide to UserDetailsService in Spring Security](https://howtodoinjava.com/spring-security/inmemory-jdbc-userdetails-service/)
* [Custom Authentication Providers in Spring Security](https://howtodoinjava.com/spring-security/custom-authentication-providers/)
* [Spring Security Context Propagation to Threads](https://howtodoinjava.com/spring-security/spring-security-context-propagation/)