# spring-emart-gns-config
Config repository for spring-emart-gns-microservices project
