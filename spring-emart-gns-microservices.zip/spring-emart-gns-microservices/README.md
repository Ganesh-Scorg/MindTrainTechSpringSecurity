# spring-emart-gns-microservices
SpringBoot Microservice project for E-commerce application

-----
This Project need mySQL database installed in local machine. Also please ignore any file or configuration related to docker since that part is pending.
-----

1. Config server: 
	To run the config server locally, need to download https://github.com/Ganesh-Scorg/spring-emart-gns-config into local directory e.g. "E:\Java fsd\Git\spring-emart-gns-config"
	Then run the config server in cmd using below command:
	java -Dserver.port=8888 -Dspring.profiles.active=native -DGIT_REPO="E:\Java fsd\Git\spring-emart-gns-config" -jar target\spring-emart-config-server-2.3.6.jar

2. Run Eureka (descovery server) using below command:
java -Dserver.port=8761 -jar target\spring-emart-discovery-server-2.3.6.jar

3. Run Admin server using below command:
java -Dserver.port=9090 -jar target\spring-emart-admin-server-2.3.6.jar

4. Run Actual app Seller service using below command:
java -Dserver.port=8081 -Dspring.profiles.active=mysql -jar target\spring-emart-sellers-service-2.3.6.jar

5. Run Actual app Buyer service using below command:
java -Dserver.port=8082 -Dspring.profiles.active=mysql -jar target\spring-emart-buyers-service-2.3.6.jar

6. Run Actual app Login service using below command:
java -Dserver.port=8083 -Dspring.profiles.active=mysql -jar target\spring-emart-login-service-2.3.6.jar

---
All above project automatically creates required table in mysql database emartgns.
now we have to manually insert few mandatory roles in table roles.
Run below sql script to add Roles:

insert into roles(name) values('ROLE_USER');
insert into roles(name) values('ROLE_BUYER');
insert into roles(name) values('ROLE_SELLER');
insert into roles(name) values('ROLE_ADMIN');
---


