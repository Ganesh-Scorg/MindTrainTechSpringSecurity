package org.gns.emart.buyers.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "products")
public class Product {

	@Id
	private String id;
	private String name;
	private String description;
	private String model;
	private Date make; // It can be date of manufacturing
	private float price;
	private int stock;
	private String sellerid;

	public Product() {

	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
	}

	public Product(String id, String name, String description, String model, Date make, float price, int stock,
			String sellerid) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.model = model;
		this.make = make;
		this.price = price;
		this.stock = stock;
		this.sellerid = sellerid;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Date getMake() {
		return make;
	}

	public void setMake(Date make) {
		this.make = make;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getSellerid() {
		return sellerid;
	}

	public void setSellerid(String sellerid) {
		this.sellerid = sellerid;
	}

}
