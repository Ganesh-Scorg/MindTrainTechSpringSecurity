package org.gns.emart.buyers.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "SalesInvoice")
@Data
@RequiredArgsConstructor
public class SalesInvoice {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer invoiceid;
	@CreationTimestamp
	private Date date_time;
	private String buyername;
	private float billedAmount;
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<Product> products;

}
