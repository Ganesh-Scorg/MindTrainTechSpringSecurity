package org.gns.emart.buyers.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "selected_product")
@Data
@RequiredArgsConstructor
public class SelectedProduct {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String buyername;
	private String productid;
	private String product_details;
	private int quantity;
	private float amount;

}
