package org.gns.emart.buyers.repository;

import org.gns.emart.buyers.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepo extends JpaRepository<Product, String> {

}
