package org.gns.emart.buyers.repository;

import java.util.List;

import org.gns.emart.buyers.model.SalesInvoice;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PurchaseHistoryRepo extends JpaRepository<SalesInvoice, Integer> {

	List<SalesInvoice> findByBuyername(String buyername);

}
