package org.gns.emart.buyers.repository;

import java.util.List;

import org.gns.emart.buyers.model.SelectedProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SelectedProductRepo extends JpaRepository<SelectedProduct, Integer> {

	List<SelectedProduct> findByBuyername(String buyername);

	void deleteByBuyername(String buyername);
}
