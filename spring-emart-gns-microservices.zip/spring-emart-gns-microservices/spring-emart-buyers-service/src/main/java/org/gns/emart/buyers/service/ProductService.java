package org.gns.emart.buyers.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.gns.emart.buyers.model.Product;
import org.gns.emart.buyers.model.SalesInvoice;
import org.gns.emart.buyers.model.SelectedProduct;
import org.gns.emart.buyers.repository.ProductRepo;
import org.gns.emart.buyers.repository.PurchaseHistoryRepo;
import org.gns.emart.buyers.repository.SelectedProductRepo;

@Service
@Slf4j
public class ProductService {
	
	@Autowired
	private ProductRepo productRepo;
	@Autowired
	private SelectedProductRepo selectedProductRepo;
	@Autowired
	private PurchaseHistoryRepo purchaseHistoryRepo;
	
	@Transactional
	public List<SelectedProduct> selectProduct(String id,Integer quantity, String buyername)
	{
		Optional<Product> product = productRepo.findById(id);
		List<SelectedProduct> selectProducts = selectedProductRepo.findByBuyername(buyername);
		
		if(product.isPresent() && product.get().getStock()>=quantity)
		{
			SelectedProduct selectedProduct = new SelectedProduct();
			selectedProduct.setBuyername(buyername);
			selectedProduct.setProductid(product.get().getId());
			selectedProduct.setProduct_details(product.get().toString());
			selectedProduct.setQuantity(quantity);
			selectedProduct.setAmount(quantity*product.get().getPrice());
			selectedProduct = selectedProductRepo.save(selectedProduct);
			selectProducts.add(selectedProduct);
		}
		else
		{
			log.info("This product is not available for sale");
			return null;
		}
		
		return selectProducts;
		
	}
	
	@Transactional
	public SalesInvoice buyProduct(String id,Integer quantity, String buyername)
	{
		Optional<Product> product = productRepo.findById(id);
		SalesInvoice invoice = new SalesInvoice();
		
		if(product.isPresent() && product.get().getStock()>=quantity)
		{
			Product prod = product.get();
			
			invoice.setBilledAmount(quantity*prod.getPrice());
			invoice.setBuyername(buyername);
			invoice.setProducts(Arrays.asList(prod));
			
			//insert invoice into table
			invoice = purchaseHistoryRepo.save(invoice);
			
			//Update stock in product table
			prod.setStock(prod.getStock()-quantity);
			productRepo.save(prod);
			
		}
		else
		{
			log.info("This product is not available for sale");
			return null;
		}
		
		return invoice;
		
	}

	@Transactional
	public SalesInvoice buyProduct(String buyername) {
		
		
		List<SelectedProduct> selectProducts = selectedProductRepo.findByBuyername(buyername);
		
		if(selectProducts == null || selectProducts.isEmpty())
		{
			return null;
		}
		
		List<Product> purchasedProducts = new ArrayList<>();
		SalesInvoice invoice = new SalesInvoice();		
		invoice.setBuyername(buyername);
		
		for(SelectedProduct p:selectProducts)
		{
			Optional<Product> product = productRepo.findById(p.getProductid());
			
			if(product.isPresent() && product.get().getStock()>=p.getQuantity())
			{
				Product prod = product.get();
				float productbill = prod.getPrice()*p.getQuantity();
						
				invoice.setBilledAmount(invoice.getBilledAmount()+productbill);
				
				//Update stock in product table
				prod.setStock(prod.getStock()-p.getQuantity());		
				purchasedProducts.add(prod);
				
			}
			else
			{
				log.info("This product is not available for sale"+p.getProduct_details());
			}
			
		}
		
		if(purchasedProducts.isEmpty())
		{
			log.info("Not A single product from cart is available for sale");
			return null;
		}
		
		invoice.setProducts(purchasedProducts);
		//insert invoice into table
		invoice = purchaseHistoryRepo.save(invoice);
		productRepo.saveAll(purchasedProducts);
		clearCart(buyername);
		
		return invoice;
	}

	public List<SelectedProduct> getSelectedProducts(String buyername) {
		return selectedProductRepo.findByBuyername(buyername);
	}

	public void clearCart(String buyername) {
		selectedProductRepo.deleteByBuyername(buyername);
	}
	
	public List<SelectedProduct> removeSelectedProduct(Integer id, String buyername) {
		 selectedProductRepo.deleteById(id);
		 return selectedProductRepo.findByBuyername(buyername);
	}

}
