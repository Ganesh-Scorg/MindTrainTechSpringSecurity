package org.gns.emart.buyers.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.gns.emart.buyers.model.Product;
import org.gns.emart.buyers.model.SalesInvoice;
import org.gns.emart.buyers.repository.PurchaseHistoryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PurchaseHistory {

	@Autowired
	private PurchaseHistoryRepo purchaseHistoryRepo;
	
	public List<SalesInvoice> viewPurchaseHistory(String buyername) {
		
		List<SalesInvoice> prevorders = purchaseHistoryRepo.findByBuyername(buyername);
		
//		if(prevorders!=null)
//		{
//			System.out.println("All your previous purchase histories are below:");
//			prevorders.forEach(o -> {
//				System.out.println(o.toString());
//			});
//		}else
//		{
//			System.out.println("You have not yet started your shopping with us, no history found..");
//		}
		
		return prevorders;
	}
	
	public SalesInvoice getInvoiceById(Integer id)
	{
		return purchaseHistoryRepo.findById(id).get();
	}

}
