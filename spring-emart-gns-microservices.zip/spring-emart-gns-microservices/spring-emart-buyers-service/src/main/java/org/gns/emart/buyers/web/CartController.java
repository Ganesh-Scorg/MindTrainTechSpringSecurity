package org.gns.emart.buyers.web;

import java.util.List;

import org.gns.emart.buyers.model.SelectedProduct;
import org.gns.emart.buyers.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/emart/product/cart")
public class CartController {

	@Autowired
	private ProductService productService;

	@PostMapping("/select/{id}/{quantity}")
	public ResponseEntity<List<SelectedProduct>> selectProduct(@PathVariable("id") String id,
			@PathVariable("quantity") Integer quantity) {
		List<SelectedProduct> selectedproducts = productService.selectProduct(id, quantity, "shindeganesh22");

		ResponseEntity<List<SelectedProduct>> response = null;

		if (selectedproducts != null && !selectedproducts.isEmpty()) {
			response = new ResponseEntity<>(selectedproducts, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return response;
	}

	@GetMapping
	public ResponseEntity<List<SelectedProduct>> getSelectedProducts() {
		List<SelectedProduct> selectedproducts = productService.getSelectedProducts("shindeganesh22");

		ResponseEntity<List<SelectedProduct>> response = null;

		if (selectedproducts != null && !selectedproducts.isEmpty()) {
			response = new ResponseEntity<>(selectedproducts, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return response;
	}

	@DeleteMapping("/remove/{id}")
	public List<SelectedProduct> removeSelectedProducts(@PathVariable("id") Integer id) {
		return productService.removeSelectedProduct(id, "shindeganesh22");
	}

	@DeleteMapping("/remove")
	public String clearUserCart() {
		productService.clearCart("shindeganesh22");
		return "Cart Cleared";
	}

}
