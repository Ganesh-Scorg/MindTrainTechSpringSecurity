package org.gns.emart.buyers.web;

import java.util.List;

import org.gns.emart.buyers.model.SalesInvoice;
import org.gns.emart.buyers.service.ProductService;
import org.gns.emart.buyers.service.PurchaseHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/emart/product/buy")
public class PurchaseController {

	@Autowired
	private ProductService productService;

	@Autowired
	private PurchaseHistory purchaseHistory;

	@PostMapping("/{id}/{quantity}")
	public ResponseEntity<SalesInvoice> buySingleProduct(@PathVariable("id") String id,
			@PathVariable("quantity") Integer quantity) {
		SalesInvoice invoice = productService.buyProduct(id, quantity, "shindeganesh22");

		ResponseEntity<SalesInvoice> response = null;

		if (invoice != null) {
			response = new ResponseEntity<>(invoice, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return response;
	}

	@PostMapping
	public ResponseEntity<SalesInvoice> buyAllProductFromCart() {
		SalesInvoice invoice = productService.buyProduct("shindeganesh22");

		ResponseEntity<SalesInvoice> response = null;

		if (invoice != null) {
			response = new ResponseEntity<>(invoice, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return response;
	}

	@GetMapping("/history")
	public ResponseEntity<List<SalesInvoice>> viewPurchaseHistory() {
		List<SalesInvoice> allinvoices = purchaseHistory.viewPurchaseHistory("shindeganesh22");

		ResponseEntity<List<SalesInvoice>> response = null;

		if (allinvoices != null && !allinvoices.isEmpty()) {
			response = new ResponseEntity<>(allinvoices, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return response;
	}
	
	@GetMapping("/history/{id}")
	public ResponseEntity<SalesInvoice> getInvoiceById(@PathVariable("id") Integer id) {
		SalesInvoice invoice = purchaseHistory.getInvoiceById(id);

		ResponseEntity<SalesInvoice> response = null;

		if (invoice != null ) {
			response = new ResponseEntity<>(invoice, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return response;
	}


}
