package org.gns.emart.login.models;

public enum ERole {
	ROLE_USER,
    ROLE_MODERATOR,
    ROLE_ADMIN,
    ROLE_BUYER,
    ROLE_SELLER
}
