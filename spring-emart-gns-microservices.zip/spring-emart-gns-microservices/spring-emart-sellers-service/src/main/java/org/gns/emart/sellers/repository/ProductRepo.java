package org.gns.emart.sellers.repository;

import java.util.List;

import org.gns.emart.sellers.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ProductRepo extends JpaRepository<Product, String> {

	List<Product> findBySellerid(String sellerid);

	@Query(value = "SELECT * FROM products p WHERE p.sellerid = :sellerid and p.id = :id", nativeQuery = true)
	Product findProductBySelleridAndIdNamedParamsNative(@Param("sellerid") String sellerid, @Param("id") String id);

	Product findBySelleridAndId(String sellerid, String id);
}
