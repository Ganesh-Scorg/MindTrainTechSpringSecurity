package org.gns.emart.sellers.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.gns.emart.sellers.model.Product;
import org.gns.emart.sellers.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ProductService {
	
	@Autowired
	private ProductRepo productRepo;
	
	public Product addProduct(Product prod)
	{
		return productRepo.save(prod);
	}
	
	public Product getProduct(String sellerid, String prodid)
	{
		//return productRepo.findBySelleridAndId(sellerid, prodid);
		return productRepo.findProductBySelleridAndIdNamedParamsNative(sellerid, prodid);
	}
	
	public void deleteProduct(String prodid)
	{
		productRepo.deleteById(prodid);
	}
	
	public Product updateProduct(String sellerid, String prodid, float price, int stock)
	{
		Product product =null;
		Optional<Product> prod =  productRepo.findById(prodid);
		
		if(prod.isPresent())
		{
			product = prod.get();
			product.setPrice(price);
			product.setStock(stock);
			
			product = productRepo.save(product);
		}
		
		if(product!=null && product.getPrice()==price && product.getStock()==stock)
		{
			System.out.println("Product Updated Successfully, see the new record below:");
			System.out.println(prod.toString());
			return product;
		}
		
		return null;
	}

	public List<Product> listProducts(String sellerid)
	{
		return productRepo.findBySellerid(sellerid);
	}
	
	
}
