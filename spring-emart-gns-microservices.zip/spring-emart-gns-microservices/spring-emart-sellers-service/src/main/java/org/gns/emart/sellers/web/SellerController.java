package org.gns.emart.sellers.web;

import java.util.List;

import javax.validation.Valid;

import org.gns.emart.sellers.model.Product;
import org.gns.emart.sellers.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/emart/product")
public class SellerController {

	@Autowired
	private ProductService productService;

	@PostMapping
	public Product addProduct(@Valid @RequestBody Product product) {
		product.setSellerid("shindeganesh22");
		return productService.addProduct(product);
	}

	@GetMapping
	public ResponseEntity<List<Product>> getProducts() {
		// User name we will get from bearer token after spring security impl, keep
		// default for now
		List<Product> allprod = productService.listProducts("shindeganesh22");

		ResponseEntity<List<Product>> response = null;

		if (allprod != null && !allprod.isEmpty()) {
			response = new ResponseEntity<>(allprod, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return response;
	}

	@GetMapping("/{id}")
	public ResponseEntity<Product> getProduct(@PathVariable("id") String productid) {
		// User name we will get from bearer token after spring security impl, keep
		// default for now
		Product prod = productService.getProduct("shindeganesh22", productid);

		ResponseEntity<Product> response = null;

		if (prod != null) {
			response = new ResponseEntity<>(prod, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return response;
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<HttpStatus> deleteProduct(@PathVariable("id") String productid) {

		try {
			productService.deleteProduct(productid);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

	@PutMapping("/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable("id") String productid,
			@RequestParam("price") float price, @RequestParam("stock") Integer stock) {

		Product product = productService.updateProduct("shindeganesh22", productid, price, stock);

		ResponseEntity<Product> response = null;

		if (product != null) {
			response = new ResponseEntity<>(product, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return response;
	}

}
