INSERT IGNORE INTO products (id, name, description, model, make, price, stock, sellerid) VALUES ('Accer67', 'Laptop Accer', 'World class laptop', 'Accer67', '2022-02-02', 56999, 8, 'sneah20shinde');
