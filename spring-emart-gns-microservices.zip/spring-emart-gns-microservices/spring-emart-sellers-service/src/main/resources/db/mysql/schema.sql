CREATE DATABASE IF NOT EXISTS emartgns;

USE emartgns;

CREATE TABLE IF NOT EXISTS products (
	id char(15), name char(50), 
	description varchar(100), 
	model char(20), 
	make Date, 
	price decimal(13,2), 
	stock integer, 
	sellerid char(15), 
	primary key (id), 
	foreign key (sellerid) references users(username)
) engine=InnoDB;

